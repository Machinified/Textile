'''
Created on Aug 12, 2011

@author: machinified
'''

from PySide.QtCore import *
from PySide.QtGui import *
from toolbar import *

class textArea(QTextEdit):
    '''
    classdocs
    '''


    def __init__(self, parent=None,):
        QTextEdit.__init__(self, None)
        self.setAcceptDrops(True)
        self.setFocus()
        self.acceptRichText()
        #self.setFont(tb.fontsDialog.getFont(0, self.font()))
        
    