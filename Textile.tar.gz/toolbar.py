'''
Created on Aug 12, 2011

@author: machinified
'''

from textedit import *

class tb(QToolBar):
    def __init__(self, parent=None):
        QToolBar.__init__(self,None)
        self.textArea = textArea()
        ## Functions
        self.File()
        self.controlFiles()
        self.clipBoard()
        self.fontDialog()
        self.controlFont()
        self.search()
        self.events()
        ## Toolbar Buttons
        self.addWidget(self.Home)
        self.addWidget(self.newFile)
        self.addWidget(self.openFile)
        self.addWidget(self.saveFile)
        self.addWidget(self.saveAs)
        self.addSeparator()
        self.addWidget(self.copyText)
        self.addWidget(self.cutText)
        self.addWidget(self.pasteText)
        self.addWidget(self.Undo)
        self.addWidget(self.Redo)
        self.addSeparator()
        self.addWidget(self.fontsButton)
        self.addWidget(self.setBold)
        self.addWidget(self.setItalic)
        self.addWidget(self.setUnderline)
        self.addWidget(self.justifyLeft)
        self.addWidget(self.justifyCenter)
        self.addWidget(self.justifyRight)
        self.addSeparator()
        self.addWidget(self.searchBox)
        self.addWidget(self.searchButton)
        
        
        
    def controlFiles(self):
        self.Home = QToolButton()
        self.Home.setIcon(QPixmap('icons/home.svg'))
        self.menu = QMenu()
        self.menu.addAction((QIcon('icons/new.svg')),'&New File')
        self.menu.addAction('&Open File')
        self.menu.addAction('&Save')
        self.menu.addAction('Save &File as')
        self.menu.addSeparator()
        self.menu.addAction('&Copy')
        self.menu.addAction('Cu&t')
        self.menu.addAction('&Paste')
        self.menu.addAction('Customi&ze Font')
        self.menu.addSeparator()
        self.menu.addAction('&Exit')
        self.Home.setMenu(self.menu)
        
        
        self.newFile = QToolButton()
        self.newFile.setIcon(QPixmap('icons/new.svg'))
        
        self.openFile = QToolButton()
        self.openFile.setIcon(QPixmap('icons/open.png'))        
        
        self.saveFile = QToolButton()
        self.saveFile.setIcon(QPixmap('icons/save.png'))
        self.saveFile.setDisabled(True)
        
        self.saveAs = QToolButton()
        self.saveAs.setIcon(QPixmap('icons/saveas.png'))
        
    
    def search(self):
        self.searchBox = QLineEdit()
        self.searchBox.setMaximumWidth(200)
        self.searchButton = QToolButton()
        searchIcon = QPixmap('icons/search.svg')
        self.searchButton.setIcon(searchIcon)
        
        
    
    def clipBoard(self):
        self.clipboard = QClipboard()
        self.copyText = QToolButton()
        self.copyText.setIcon(QPixmap('icons/copy.svg'))
        self.cutText = QToolButton()
        self.cutText.setIcon(QPixmap('icons/cut.svg'))
        self.pasteText = QToolButton()
        self.pasteText.setIcon(QPixmap('icons/paste.svg'))
        self.Undo = QToolButton()
        self.Undo.setIcon(QPixmap('icons/undo.svg'))
        self.Redo = QToolButton()
        self.Redo.setIcon(QPixmap('icons/redo.svg'))
        
         
    def controlFont(self):
        self.fontsButton = QToolButton()
        self.fontsButton.setIcon(QPixmap('icons/fonts.png'))
        self.connect(self.fontsButton, SIGNAL('clicked()'), self.fontsDialog, SLOT('show()'))
                
        self.setBold = QToolButton()
        self.setBold.setIcon(QPixmap('icons/format-text-bold.png'))
        
        self.setItalic = QToolButton()
        self.setItalic.setIcon(QPixmap('icons/format-text-italic.png'))
        
        self.setUnderline = QToolButton()
        self.setUnderline.setIcon(QPixmap('icons/format-text-underline.png'))
        
        self.justifyLeft = QToolButton()
        self.justifyLeft.setIcon(QPixmap('icons/format-justify-left.png'))
        
        self.justifyCenter = QToolButton()
        self.justifyCenter.setIcon(QPixmap('icons/format-justify-center.png'))
        
        self.justifyRight = QToolButton()
        self.justifyRight.setIcon(QPixmap('icons/format-justify-right.png'))
        
    
    def fontDialog(self):
        self.fontsDialog = QFontDialog()
        
    def File(self):
        self.fileName = None
        
            
    
    def openDialogFunc(self):
        self.openDialog = QFileDialog(self)
        self.fileName = self.openDialog.getOpenFileName(self,'Open File','/home')
        self.file = open(self.fileName[0], 'r+')
        data = self.file.read()
        self.textArea.setText(data)
        if self.fileName != None:
            self.saveFile.setDisabled(False)
        
        
        
    def saveDialog(self):
        data = self.textArea.toPlainText()
        file = open(self.fileName[0], 'w')
        file.write(data)
        file.close()
        
    def saveAsDialog(self):
        self.saveasDialog = QFileDialog(self)
        self.fileName = self.saveasDialog.getSaveFileName(self,'Save File As','/home')
        self.saveDialog()
        
        

            
    def events(self):
        self.connect(self.Home, SIGNAL('clicked()'), self.Home, SLOT('showMenu()'))
        self.connect(self.openFile, SIGNAL('clicked()'), self, SLOT('openDialogFunc()'))
        self.connect(self.saveFile, SIGNAL('clicked()'), self, SLOT('saveDialog()'))
        self.connect(self.saveAs, SIGNAL('clicked()'), self, SLOT('saveAsDialog()'))
        self.connect(self.copyText, SIGNAL('clicked()'), self.textArea, SLOT('copy()'))
        self.connect(self.cutText, SIGNAL('clicked()'), self.textArea, SLOT('cut()'))
        self.connect(self.pasteText, SIGNAL('clicked()'), self.textArea, SLOT('paste()'))
        self.connect(self.Undo, SIGNAL('clicked()'), self.textArea, SLOT('undo()'))
        self.connect(self.Redo, SIGNAL('clicked()'), self.textArea, SLOT('redo()'))
        self.connect(self.setBold, SIGNAL('clicked()'), self.textArea, SLOT('setFontWeight(1)'))
        self.connect(self.setUnderline, SIGNAL('clicked()'), self.textArea, SLOT('setFontUnderline(True)'))
        self.connect(self.setItalic, SIGNAL('clicked()'), self.textArea, SLOT('setFontItalic()'))
        self.connect(self.justifyLeft, SIGNAL('clicked()'), self.textArea, SLOT("setAlignment('left')"))
        self.connect(self.justifyCenter, SIGNAL('clicked()'), self.textArea, SLOT("setAlignment('center')"))
        self.connect(self.justifyRight, SIGNAL('clicked()'), self.textArea, SLOT("setAlignment('right')"))
        if self.searchBox.text() != ' ':
            self.connect(self.searchButton, SIGNAL('clicked()'), self.textArea, SLOT('find(self.searchBox.text())'))