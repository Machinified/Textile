'''
Created on Aug 12, 2011

@author: machinified
'''
from toolbar import *
from sys import argv,exit


class MainWindow(QWidget):
    '''
    classdocs
    '''


    def __init__(self, parent=None):
        QWidget.__init__(self, None)
        self.setMinimumHeight(500)
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width()-size.width())/2, (screen.height()-size.height())/2)
        self.setWindowTitle("Textile")
        self.toolBar = tb()
        #self.textArea = textArea()
        self.layout()


    def layout(self):
        self.main = QVBoxLayout()
        self.main.addWidget(self.toolBar)
        self.main.addWidget(self.toolBar.textArea)
        self.setLayout(self.main)
        
        
if __name__ == '__main__':
    app = QApplication(argv)
    Notz = MainWindow()
    Notz.show()
    
    app.exec_()
    exit
        
        
        